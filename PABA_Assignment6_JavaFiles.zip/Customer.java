// Class representing a customer
public class Customer {
    private String name; // Customer's name
    private int age; // Customer's age

    // Constructor to create a Customer object with a name and age
    public Customer(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Copy constructor to create a Customer object by copying another Customer object's properties
    public Customer(Customer c) {
        this.name = c.name;
        this.age = c.age;
    }

    // Getter for retrieving the customer's age
    public int getAge() {
        return age;
    }

    // Setter for updating the customer's age
    public void setAge(int age) {
        this.age = age;
    }

    // Getter for retrieving the customer's name
    public String getName() {
        return name;
    }

    // Setter for updating the customer's name
    public void setName(String name) {
        this.name = name;
    }

    // Generate a string representation of the Customer object
    @Override
    public String toString() {
        return "Customer: " + name + ", Age: " + age;
    }

    // Check if two Customer objects are equal based on their properties
    public boolean equals(Customer cust) {
        return age == cust.age && name.equals(cust.name);
    }
}
