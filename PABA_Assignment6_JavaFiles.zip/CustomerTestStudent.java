import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CustomerTestStudent {

    @Test
    void testCustomerConstructorAndGetters() {
        Customer customer = new Customer("John", 25);
        assertEquals("John", customer.getName());
        assertEquals(25, customer.getAge());
    }

    @Test
    void testCopyConstructor() {
        Customer originalCustomer = new Customer("Alice", 30);
        Customer copiedCustomer = new Customer(originalCustomer);
        
        assertEquals(originalCustomer.getName(), copiedCustomer.getName());
        assertEquals(originalCustomer.getAge(), copiedCustomer.getAge());
    }

    @Test
    void testSetters() {
        Customer customer = new Customer("Bob", 28);
        
        customer.setName("Charlie");
        assertEquals("Charlie", customer.getName());

        customer.setAge(35);
        assertEquals(35, customer.getAge());
    }

    @Test
    void testToString() {
        Customer customer = new Customer("Eve", 22);
        assertEquals("Customer: Eve, Age: 22", customer.toString());
    }

    @Test
    void testEquals() {
        Customer customer1 = new Customer("Sam", 40);
        Customer customer2 = new Customer("Sam", 40);
        Customer customer3 = new Customer("Anna", 35);

        assertTrue(customer1.equals(customer2));
        assertFalse(customer1.equals(customer3));
    }
}
