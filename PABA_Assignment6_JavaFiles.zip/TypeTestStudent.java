import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TypeTestStudent {

    @Test
    void testEnumValues() {
        Type coffee = Type.COFFEE;
        Type smoothie = Type.SMOOTHIE;
        Type alcohol = Type.ALCOHOL;

        assertEquals("COFFEE", coffee.name());
        assertEquals("SMOOTHIE", smoothie.name());
        assertEquals("ALCOHOL", alcohol.name());
    }

    @Test
    void testEnumOrdinal() {
        Type coffee = Type.COFFEE;
        Type smoothie = Type.SMOOTHIE;
        Type alcohol = Type.ALCOHOL;

        assertEquals(0, coffee.ordinal());
        assertEquals(1, smoothie.ordinal());
        assertEquals(2, alcohol.ordinal());
    }
}
