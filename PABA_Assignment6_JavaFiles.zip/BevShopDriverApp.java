import java.util.Scanner;

public class BevShopDriverApp {
    public static void main(String[] args) {
        BevShop bevShop = new BevShop();
        var sc = new Scanner(System.in);
        int drinksDesired = 0;
        
        System.out.println("The current order in process can have at most " + bevShop.getMaxOrderForAlcohol() + " alcoholic beverages.");
        System.out.println("The minimum age to order alcohol drink is " + bevShop.getMinAgeForAlcohol());
        
        System.out.println("Start please a new order:");
        System.out.print("Would you please enter your name: ");
        String name = sc.nextLine();
        System.out.print("Would you please enter your age: ");
        int age = sc.nextInt();
        sc.nextLine(); // Consume the newline
        bevShop.startNewOrder(10, Day.FRIDAY, name, age);
        
        
        if (bevShop.isValidAge(age)) {
            System.out.println("Your age is above " + bevShop.getMinAgeForAlcohol() + " and you are eligible to order alcohol");
            
            while (bevShop.isEligibleForMore() && bevShop.getNumOfAlcoholDrink() < bevShop.getMaxOrderForAlcohol()) {
                System.out.println("Your current alcohol drink order is less than " + bevShop.getMaxOrderForAlcohol());
                System.out.print("Would you please add a new alcohol drink: ");
                String alcoholDrinkName = sc.nextLine();
                
                bevShop.processAlcoholOrder(alcoholDrinkName, Size.SMALL);
                System.out.println("The current order of drinks is " + bevShop.getCurrentOrder().getTotalItems());
                System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
            }
            
            System.out.println("You have a maximum alcohol drinks for this order");
            
            System.out.print("Would you please add a COFFEE to your order: ");
            String coffeeName = sc.nextLine();
            System.out.print("What Size? Small, medium, or large? ");
            String sizeAnswer = sc.nextLine();
            Size size = sizeAnswer.equalsIgnoreCase("small") ? Size.SMALL : sizeAnswer.equalsIgnoreCase("medium")? Size.MEDIUM : Size.LARGE;
            System.out.print("Would you like an extra shot of coffee? type yes or no ");
            String extraShotAns = sc.nextLine();
            boolean extraShot = extraShotAns.charAt(0) == 'y' ? true : false;
            
            System.out.print("Would you like extra syrup in your coffee? type yes or no ");
            String extraSyrupAns = sc.nextLine();
            boolean extraSyrup = extraSyrupAns.charAt(0) == 'y' ? true : false;
           
            bevShop.processCoffeeOrder(coffeeName, size, extraShot, extraSyrup);
            System.out.println("Total items on your order is " + bevShop.getCurrentOrder().getTotalItems());
            System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        } else {
            System.out.println("Your Age is not appropriate for alcohol drink!!");
            
            System.out.print("Would you please add a COFFEE to your order: ");
            String coffeeName = sc.nextLine();
            System.out.print("What Size? Small, medium, or large? ");
            String sizeAnswer = sc.nextLine();
            Size size = sizeAnswer.equalsIgnoreCase("small") ? Size.SMALL : sizeAnswer.equalsIgnoreCase("medium")? Size.MEDIUM : Size.LARGE;
            System.out.print("Would you like an extra shot of coffee? type yes or no ");
            String extraShotAns = sc.nextLine();
            boolean extraShot = extraShotAns.charAt(0) == 'y' ? true : false;
            
            System.out.print("Would you like extra syrup in your coffee? type yes or no ");
            String extraSyrupAns = sc.nextLine();
            boolean extraSyrup = extraSyrupAns.charAt(0) == 'y' ? true : false;
           
            bevShop.processCoffeeOrder(coffeeName, size, extraShot, extraSyrup);
            System.out.println("Total items on your order is " + bevShop.getCurrentOrder().getTotalItems());
            System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        }
        
        System.out.println("#------------------------------------#");
        
        System.out.println("Would you please start a new order");
        System.out.print("Would you please enter your name: ");
        String name2 = sc.nextLine();
        System.out.print("Would you please enter your age: ");
        int age2 = sc.nextInt();
        sc.nextLine(); // Consume the newline
        
        bevShop.startNewOrder(14, Day.SATURDAY, name2, age2);
        System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        
        System.out.print("Would you please add a SMOOTHIE to order: ");
        String smoothieName = sc.nextLine();
        bevShop.processSmoothieOrder(smoothieName, Size.MEDIUM, 3, true);
        System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        
        System.out.print("Would you please add a SMOOTHIE to order: ");
        smoothieName = sc.nextLine();
        bevShop.processSmoothieOrder(smoothieName, Size.SMALL, 2, false);
        
        System.out.print("Would you please add a COFFEE to order: ");
        String coffeeName2 = sc.nextLine();
        bevShop.processCoffeeOrder(coffeeName2, Size.MEDIUM, false, true);
        System.out.println("The Total Price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        
        System.out.print("Would you please add an Alcoholic drink: ");
        if (bevShop.isValidAge(age2)) {
            String alcoholDrinkName = sc.nextLine();
            bevShop.processAlcoholOrder(alcoholDrinkName, Size.LARGE);
        } else {
            System.out.println("Your Age is not appropriate for alcohol drink!!");
        }
        System.out.println("The current order of drinks is " + bevShop.getCurrentOrder().getTotalItems());
        System.out.println("The Total price on the Order: " + bevShop.getCurrentOrder().calcOrderTotal());
        
        System.out.println("The total number of fruits is " + bevShop.getNumOfAlcoholDrink());
        if (bevShop.isMaxFruit(5)) {
            System.out.println("You reached a Maximum number of fruits");
        }
        
        System.out.println("Total price on the second Order: " + bevShop.getOrderAtIndex(1).calcOrderTotal());
        System.out.println("Total amount for all Orders: " + bevShop.totalMonthlySale());
        
        // Close the scanner
        sc.close();
    }
}
