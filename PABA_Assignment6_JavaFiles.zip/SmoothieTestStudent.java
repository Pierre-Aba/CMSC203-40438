import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SmoothieTestStudent {

    @Test
    void testGetNumFruits() {
        Smoothie smoothie = new Smoothie("Berry Blast", Size.MEDIUM, 3, true);
        assertEquals(3, smoothie.getNumFruits());
    }

    @Test
    void testGetAddProtein() {
        Smoothie smoothie = new Smoothie("Berry Blast", Size.MEDIUM, 3, true);
        assertTrue(smoothie.getAddProtein());
    }

    @Test
    void testCalcPriceWithoutProtein() {
        Smoothie smoothie = new Smoothie("Tropical Delight", Size.LARGE, 5, false);
        
        assertEquals(6.5, smoothie.calcPrice());
    }

    @Test
    void testCalcPriceWithProtein() {
        Smoothie smoothie = new Smoothie("Protein Power", Size.SMALL, 2, true);
        
        assertEquals(4.5, smoothie.calcPrice());
    }

    @Test
    void testToString() {
        Smoothie smoothie = new Smoothie("Mango Madness", Size.MEDIUM, 4, false);
        String expectedText = "Smoothie: Mango Madness, Size: MEDIUM, without Protein Powder, 4 fruits, Price: $"
                + String.format("%.2f", smoothie.calcPrice());
        assertEquals(expectedText, smoothie.toString());
    }

    @Test
    void testEquals() {
        Smoothie smoothie1 = new Smoothie("Strawberry Bliss", Size.LARGE, 2, true);
        Smoothie smoothie2 = new Smoothie("Strawberry Bliss", Size.LARGE, 2, true);
        assertTrue(smoothie1.equals(smoothie2));
    }

    @Test
    void testSetNumFruits() {
        Smoothie smoothie = new Smoothie("Peach Passion", Size.SMALL, 1, false);
        smoothie.setNumFruits(3);
        assertEquals(3, smoothie.getNumFruits());
    }

    @Test
    void testSetProteinPowder() {
        Smoothie smoothie = new Smoothie("Choco Power", Size.LARGE, 4, false);
        smoothie.setProteinPowder(true);
        assertTrue(smoothie.getAddProtein());
    }
}
