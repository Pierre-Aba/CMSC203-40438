import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class OrderTestStudent {

    @Test
    void testGenerateOrder() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        int generatedOrderNo = order.generateOrder();
        
        assertTrue(generatedOrderNo >= 10000 && generatedOrderNo <= 90000);
    }

    @Test
    void testGetOrderNo() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        
        assertEquals(order.getOrderNo(), order.generateOrder());
    }

    @Test
    void testGetOrderTime() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        
        assertEquals(12, order.getOrderTime());
    }

    @Test
    void testGetOrderDay() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        
        assertEquals(Day.MONDAY, order.getOrderDay());
    }

    @Test
    void testGetCustomer() {
        Customer customer = new Customer("John", 30);
        Order order = new Order(12, Day.MONDAY, customer);
        
        assertEquals(customer.getName(), order.getCustomer().getName());
        assertEquals(customer.getAge(), order.getCustomer().getAge());
    }

    @Test
    void testIsWeekend() {
        Order orderWeekend = new Order(12, Day.SATURDAY, new Customer("John", 30));
        Order orderWeekday = new Order(12, Day.MONDAY, new Customer("John", 30));
        
        assertTrue(orderWeekend.isWeekend());
        assertFalse(orderWeekday.isWeekend());
    }

    @Test
    void testGetBeverage() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        order.addNewBeverage("Latte", Size.MEDIUM, true, false);
        
        assertEquals("Latte", order.getBeverage(0).getBevName());
        assertNull(order.getBeverage(1));
    }

    @Test
    void testGetTotalItems() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        order.addNewBeverage("Latte", Size.MEDIUM, true, false);
        
        assertEquals(1, order.getTotalItems());
    }

    @Test
    void testCalcOrderTotal() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        order.addNewBeverage("Latte", Size.MEDIUM, true, false);
        order.addNewBeverage("Wine", Size.LARGE);
        
        double expectedTotal = order.getBeverage(0).calcPrice() + order.getBeverage(1).calcPrice();
        assertEquals(expectedTotal, order.calcOrderTotal());
    }

    @Test
    void testFindNumOfBeveType() {
        Order order = new Order(12, Day.MONDAY, new Customer("John", 30));
        order.addNewBeverage("Latte", Size.MEDIUM, true, false);
        order.addNewBeverage("Wine", Size.LARGE);
        
        assertEquals(1, order.findNumOfBeveType(Type.COFFEE));
        assertEquals(1, order.findNumOfBeveType(Type.ALCOHOL));
        assertEquals(0, order.findNumOfBeveType(Type.SMOOTHIE));
    }
}
