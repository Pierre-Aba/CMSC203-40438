import java.util.ArrayList;
import java.util.Random;

// Class representing an order of beverages
public class Order implements OrderInterface, Comparable<Order> {
    private int orderNo; // Order number
    private int orderTime; // Time of the order
    private Day orderDay; // Day of the order
    private Customer cust; // Customer associated with the order
    private ArrayList<Beverage> beverages; // List of beverages in the order

    // Constructor to create an order with specified attributes
    public Order(int orderTime, Day orderDay, Customer cust) {
        this.orderNo = generateOrder(); // Generate a unique order number
        this.orderTime = orderTime;
        this.orderDay = orderDay;
        this.cust = new Customer(cust); // Create a deep copy of the customer
        this.beverages = new ArrayList<>(); // Initialize the list of beverages
    }

    // Method to generate a unique order number
    public int generateOrder() {
        Random rand = new Random();
        return rand.nextInt(80000) + 10000;
    }

    // Getter for retrieving the order number
    public int getOrderNo() {
        return orderNo;
    }

    // Getter for retrieving the order time
    public int getOrderTime() {
        return orderTime;
    }

    // Getter for retrieving the order day
    public Day getOrderDay() {
        return orderDay;
    }

    // Getter for retrieving a deep copy of the customer associated with the order
    public Customer getCustomer() {
        return new Customer(cust.getName(), cust.getAge());
    }

    // Method to determine if the order was placed on a weekend
    public boolean isWeekend() {
        return orderDay == Day.SATURDAY || orderDay == Day.SUNDAY;
    }

    // Method to retrieve a beverage from the order by its item number
    public Beverage getBeverage(int itemNo) {
        if (itemNo >= 0 && itemNo < beverages.size()) {
            return beverages.get(itemNo);
        }
        return null;
    }

    // Method to get the total number of beverages in the order
    public int getTotalItems() {
        return beverages.size();
    }

    // Method to add a new alcohol beverage to the order
    public void addNewBeverage(String bevName, Size size) {
        beverages.add(new Alcohol(bevName, size, isWeekend()));
    }

    // Method to add a new coffee beverage to the order
    public void addNewBeverage(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
        beverages.add(new Coffee(bevName, size, extraShot, extraSyrup));
    }

    // Method to add a new smoothie beverage to the order
    public void addNewBeverage(String bevName, Size size, int numOfFruits, boolean addProtein) {
        beverages.add(new Smoothie(bevName, size, numOfFruits, addProtein));
    }

    // Method to calculate the total cost of the order
    public double calcOrderTotal() {
        double total = 0.0;
        for (Beverage beverage : beverages) {
            total += beverage.calcPrice();
        }
        return total;
    }

    // Method to find the number of beverages of a specific type in the order
    public int findNumOfBeveType(Type type) {
        int count = 0;
        for (Beverage beverage : beverages) {
            if (beverage.getType() == type) {
                count++;
            }
        }
        return count;
    }

    // Generate a string representation of the Order object
    @Override
    public String toString() {
        String beveragesText = "";
        for (Beverage beverage : beverages) {
            beveragesText += beverage + "\n";
        }
        String totalAmountText = String.format("%.2f", calcOrderTotal());

        return "Order Number: " + orderNo +
               "\nOrder Time: " + orderTime +
               "\nOrder Day: " + orderDay +
               "\nCustomer: " + cust +
               "\nBeverages: \n" + beveragesText +
               "Total Amount: $" + totalAmountText;
    }

    // Compare two orders for sorting purposes
    @Override
    public int compareTo(Order anotherOrder) {
        if (this.orderNo == anotherOrder.orderNo) {
            return 0;
        } else if (this.orderNo > anotherOrder.orderNo) {
            return 1;
        } else {
            return -1;
        }
    }
}
