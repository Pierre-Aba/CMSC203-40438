import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AlcoholTestStudent {

    @Test
    void testCalcPrice() {
        Alcohol alcoholWeekend = new Alcohol("Beer", Size.MEDIUM, true);
        Alcohol alcoholWeekday = new Alcohol("Wine", Size.LARGE, false);

        assertEquals(3.60, alcoholWeekend.calcPrice(), 0.01);
        assertEquals(4.00, alcoholWeekday.calcPrice(), 0.01);
    }

    @Test
    void testToString() {
        Alcohol alcohol = new Alcohol("Beer", Size.SMALL, true);
        String expected = "Alcohol: Beer, Size: SMALL, Offered in the Weekend, Price: $2.60";

        assertEquals(expected, alcohol.toString());
    }

    @Test
    void testEquals() {
        Alcohol alcohol1 = new Alcohol("Jack&Coke", Size.MEDIUM, true);
        Alcohol alcohol2 = new Alcohol("Jack&Coke", Size.MEDIUM, true);
        Alcohol alcohol3 = new Alcohol("Whiskey", Size.LARGE, false);

        assertTrue(alcohol1.equals(alcohol2));
        assertFalse(alcohol1.equals(alcohol3));
    }

    @Test
    void testSetIsWeekend() {
        Alcohol alcohol = new Alcohol("Vodka", Size.LARGE, false);

        alcohol.setIsWeekend(true);
        assertTrue(alcohol.isWeekend());
    }
}
