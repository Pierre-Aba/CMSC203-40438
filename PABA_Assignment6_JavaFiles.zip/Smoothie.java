// Class representing a Smoothie which is a type of Beverage
public class Smoothie extends Beverage {

    private int numOfFruits; // Number of fruits added to the smoothie
    private boolean addProtein; // Flag indicating if protein powder is added
    final private double FRUITCOST = 0.5; // Cost per fruit added
    final private double PROTEINCOST = 1.5; // Cost for adding protein powder

    // Constructor to create a Smoothie object with specified attributes
    public Smoothie(String bevName, Size size, int numFruits, boolean proteinPowder) {
        super(bevName, Type.SMOOTHIE, size); // Call the superclass constructor
        this.numOfFruits = numFruits; // Set the number of fruits
        this.addProtein = proteinPowder; // Set the protein powder flag
    }

    // Getter for retrieving the number of fruits in the smoothie
    public int getNumFruits() {
        return numOfFruits;
    }

    // Getter for retrieving whether protein powder is added
    public boolean getAddProtein() {
        return addProtein;
    }
    

    // Calculate the price of the smoothie based on its components
    @Override
    public double calcPrice() {
        double smoothieCost = 0.0;
        smoothieCost += addSizePrice() + (numOfFruits * FRUITCOST); // Adds Beverage Size Price and Fruit Cost

        if (addProtein) 
            smoothieCost += PROTEINCOST; // Add protein powder cost

        return smoothieCost;
    }

    // Generate a string representation of the Smoothie object
    @Override
    public String toString() {
        String proteinText = addProtein ? "with Protein Powder" : "without Protein Powder";
        return "Smoothie: " + getBevName() + ", Size: " + getSize() + ", " + proteinText + ", " +
               numOfFruits + " fruits, Price: $" + String.format("%.2f", calcPrice());
    }

    // Check if two Smoothie objects are equal based on their properties
    public boolean equals(Smoothie smoothie) {
        return  numOfFruits == smoothie.numOfFruits &&
               addProtein == smoothie.addProtein &&
               getBevName().equals(smoothie.getBevName()) &&
               getType() == smoothie.getType() &&
               getSize() == smoothie.getSize();
    }

    // Setter for updating the number of fruits in the smoothie
    public void setNumFruits(int numFruits) {
        this.numOfFruits = numFruits;
    }

    // Setter for updating the protein powder status
    public void setProteinPowder(boolean proteinPowder) {
        this.addProtein = proteinPowder;
    }
}
