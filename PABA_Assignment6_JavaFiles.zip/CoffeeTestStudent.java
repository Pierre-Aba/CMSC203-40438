import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CoffeeTestStudent {

    @Test
    void testCalcPriceWithoutExtras() {
        Coffee coffee = new Coffee("Latte", Size.MEDIUM, false, false);
        assertEquals(3, coffee.calcPrice());
    }

    @Test
    void testCalcPriceWithExtraShot() {
        Coffee coffee = new Coffee("Cappuccino", Size.LARGE, true, false);
        assertEquals(4.5, coffee.calcPrice());
    }

    @Test
    void testCalcPriceWithExtraSyrup() {
        Coffee coffee = new Coffee("Mocha", Size.SMALL, false, true);
        assertEquals(2.5, coffee.calcPrice());
    }

    @Test
    void testCalcPriceWithExtras() {
        Coffee coffee = new Coffee("Espresso", Size.MEDIUM, true, true);
        assertEquals(4, coffee.calcPrice());
    }

    @Test
    void testToStringWithoutExtras() {
        Coffee coffee = new Coffee("Latte", Size.MEDIUM, false, false);
        assertEquals("Coffee: Latte, Size: MEDIUM, without Extra Shot, without Extra Syrup, Price: $3.00", coffee.toString());
    }

    @Test
    void testToStringWithExtraShot() {
        Coffee coffee = new Coffee("Cappuccino", Size.LARGE, true, false);
        assertEquals("Coffee: Cappuccino, Size: LARGE, with Extra Shot, without Extra Syrup, Price: $4.50", coffee.toString());
    }

    @Test
    void testToStringWithExtraSyrup() {
        Coffee coffee = new Coffee("Mocha", Size.SMALL, false, true);
        assertEquals("Coffee: Mocha, Size: SMALL, without Extra Shot, with Extra Syrup, Price: $2.50", coffee.toString());
    }

    @Test
    void testToStringWithExtras() {
        Coffee coffee = new Coffee("Espresso", Size.MEDIUM, true, true);
        assertEquals("Coffee: Espresso, Size: MEDIUM, with Extra Shot, with Extra Syrup, Price: $4.00", coffee.toString());
    }

    @Test
    void testEquals() {
        Coffee coffee1 = new Coffee("Latte", Size.MEDIUM, true, false);
        Coffee coffee2 = new Coffee("Latte", Size.MEDIUM, true, false);
        assertTrue(coffee1.equals(coffee2));
    }

    @Test
    void testSetExtraShot() {
        Coffee coffee = new Coffee("Espresso", Size.SMALL, false, false);
        coffee.setExtraShot(true);
        assertTrue(coffee.getExtraShot());
    }

    @Test
    void testSetExtraSyrup() {
        Coffee coffee = new Coffee("Mocha", Size.LARGE, false, false);
        coffee.setExtraSyrup(true);
        assertTrue(coffee.getExtraSyrup());
    }
}
