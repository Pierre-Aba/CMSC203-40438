/*
 * Class: CMSC203 40438
 * Instructor: Professor Grinberg
 * Due: 8/7/2023
 * Platform/compiler: Eclipse Workspace
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Pierre Aba
 */

// Class representing an Alcohol beverage, extending the Beverage class
public class Alcohol extends Beverage {

    private boolean isWeekend; // Indicates if the beverage is available on weekends
    final private double WEEKENDCOST = 0.6; // Additional cost for weekend availability

    // Constructor to initialize Alcohol properties
    public Alcohol(String bevName, Size size, boolean isWeekend) {
        super(bevName, Type.ALCOHOL, size); // Call parent class constructor
        this.isWeekend = isWeekend;
    }

    // Check if the beverage is available on weekends
    public boolean isWeekend() {
        return isWeekend;
    }

    // Calculate the price of the Alcohol beverage
    @Override
    public double calcPrice() {
        double alcoholCost = 0.0; // Initialize the cost
        alcoholCost += addSizePrice(); // Add base and size cost
        
        if (isWeekend)
            alcoholCost += WEEKENDCOST; // Add weekend cost if applicable

        return alcoholCost; // Return the calculated cost
    }

    // Create a string representation of the Alcohol beverage
    @Override
    public String toString() {
        String weekendText = isWeekend ? "Offered in the Weekend" : "Not Offered in the Weekend";
        return "Alcohol: " + getBevName() + ", Size: " + getSize() + ", " + weekendText +
               ", Price: $" + String.format("%.2f", calcPrice());
    }

    // Check if two Alcohol beverages are equal based on their properties
    public boolean equals(Alcohol alc) {
        return getBevName().equals(alc.getBevName()) &&
               getType() == alc.getType() &&
               getSize() == alc.getSize() &&
               isWeekend == alc.isWeekend;
    }

    // Setter to update the weekend availability of the Alcohol beverage
    public void setIsWeekend(boolean weekendOffer) {
        this.isWeekend = weekendOffer;
    }
}
