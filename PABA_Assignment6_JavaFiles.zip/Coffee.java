/*
 * Class: CMSC203 40438
 * Instructor: Professor Grinberg
 
 * Due: 8/7/2023
 * Platform/compiler: Eclipse Workspace
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Pierre Aba
 */
public class Coffee extends Beverage {

	private boolean extraShot;
	private boolean extraSyrup;
	final private double EXTRASHOTCOST = .5;
	final private double EXTRASYRUPCOST = .5;
	
	 public Coffee(String bevName, Size size, boolean extraShot, boolean extraSyrup) {
	        super(bevName, Type.COFFEE, size);
	        this.extraShot = extraShot;
	        this.extraSyrup = extraSyrup;
	    }
	 public boolean getExtraShot()
	 {
		 return extraShot;
	 }
	 
	 public boolean getExtraSyrup()
	 {
		 return extraSyrup;
	 }
	@Override
	public double calcPrice() {
		double coffeeCost = 0.0;
		coffeeCost+=addSizePrice();
		
		if(extraShot)
			coffeeCost+=EXTRASHOTCOST;
		
		if(extraSyrup)
			coffeeCost+=EXTRASYRUPCOST;
		return coffeeCost;
	}
	
	@Override
	public String toString() {
	    String extraShotText = extraShot ? "with Extra Shot" : "without Extra Shot";
	    String extraSyrupText = extraSyrup ? "with Extra Syrup" : "without Extra Syrup";
	    
	    return "Coffee: " + getBevName() + ", Size: " + getSize() + ", " + extraShotText + ", " + extraSyrupText +
	           ", Price: $" + String.format("%.2f", calcPrice());
	}
	public boolean equals(Coffee bev) {
	  
	    
	    return extraShot == bev.extraShot &&
	           extraSyrup == bev.extraSyrup &&
	           getBevName().equals(bev.getBevName()) &&
	           getType() == bev.getType() &&
	           getSize() == bev.getSize();
	}
	

    // Setter for extraShot
    public void setExtraShot(boolean extraShot) {
        this.extraShot = extraShot;
    }

  
    // Setter for extraSyrup
    public void setExtraSyrup(boolean extraSyrup) {
        this.extraSyrup = extraSyrup;
    }


}
