public enum Size {
    SMALL,
    MEDIUM,
    LARGE
}
