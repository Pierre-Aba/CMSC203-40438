import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BevShopTest {

    @Test
    void testIsValidTime() {
        BevShop bevShop = new BevShop();
        assertTrue(bevShop.isValidTime(10));
        assertFalse(bevShop.isValidTime(6));
    }

    @Test
    void testGetMaxNumOfFruits() {
        BevShop bevShop = new BevShop();
        assertEquals(5, bevShop.getMaxNumOfFruits());
    }

    @Test
    void testGetMinAgeForAlcohol() {
        BevShop bevShop = new BevShop();
        assertEquals(21, bevShop.getMinAgeForAlcohol());
    }

    // Add similar test methods for other methods in BevShop class

    @Test
    void testIsValidAge() {
        BevShop bevShop = new BevShop();
        assertTrue(bevShop.isValidAge(25));
        assertFalse(bevShop.isValidAge(18));
    }

    @Test
    void testStartNewOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        assertNotNull(bevShop.getCurrentOrder());
        assertEquals("John", bevShop.getCurrentOrder().getCustomer().getName());
    }

    // Add similar test methods for other methods in BevShop class

    @Test
    void testSortOrders() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);

        bevShop.sortOrders();
        assertEquals(12, bevShop.getOrderAtIndex(0).getOrderTime());
        assertEquals(10, bevShop.getOrderAtIndex(1).getOrderTime());
    }
    @Test
    void testProcessCoffeeOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        
        bevShop.processCoffeeOrder("Latte", Size.MEDIUM, true, false);
        assertEquals("Latte", bevShop.getCurrentOrder().getBeverage(0).getBevName());
    }

    @Test
    void testProcessAlcoholOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        
        bevShop.processAlcoholOrder("Wine", Size.LARGE);
        assertEquals("Wine", bevShop.getCurrentOrder().getBeverage(0).getBevName());
    }

    @Test
    void testProcessSmoothieOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        
        bevShop.processSmoothieOrder("Berry Blast", Size.SMALL, 3, true);
        assertEquals("Berry Blast", bevShop.getCurrentOrder().getBeverage(0).getBevName());
    }

    @Test
    void testFindOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);
        
        assertEquals(0, bevShop.findOrder(bevShop.getCurrentOrder().getOrderNo()));
        assertEquals(1, bevShop.findOrder(bevShop.getOrderAtIndex(1).getOrderNo()));
        assertEquals(-1, bevShop.findOrder(99999));
    }

    @Test
    void testTotalOrderPrice() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.processCoffeeOrder("Latte", Size.MEDIUM, true, false);
        
        double expectedPrice = bevShop.getCurrentOrder().getBeverage(0).calcPrice();
        assertEquals(expectedPrice, bevShop.totalOrderPrice(bevShop.getCurrentOrder().getOrderNo()));
    }

    @Test
    void testTotalMonthlySale() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);
        bevShop.processCoffeeOrder("Latte", Size.MEDIUM, true, false);
        bevShop.processAlcoholOrder("Wine", Size.LARGE);
        
        //Total is 4(Large nonweekend alcohol) + 3.5(medium coffee with one extra shot) = 7.5
        assertEquals(7.5, bevShop.totalMonthlySale());
    }

    @Test
    void testTotalNumOfMonthlyOrders() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);
        
        assertEquals(2, bevShop.totalNumOfMonthlyOrders());
    }

    @Test
    void testGetCurrentOrder() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);
        
        assertEquals(bevShop.getOrderAtIndex(1), bevShop.getCurrentOrder());
    }

    @Test
    void testGetOrderAtIndex() {
        BevShop bevShop = new BevShop();
        bevShop.startNewOrder(12, Day.MONDAY, "John", 30);
        bevShop.startNewOrder(10, Day.TUESDAY, "Alice", 25);
        
        assertEquals(bevShop.getCurrentOrder(), bevShop.getOrderAtIndex(1));
    }
}
