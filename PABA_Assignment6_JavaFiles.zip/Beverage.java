/*
 * Class: CMSC203 40438
 * Instructor: Professor Grinberg
 * Due: 8/7/2023
 * Platform/compiler: Eclipse Workspace
 * I pledge that I have completed the programming
 * assignment independently. I have not copied the code
 * from a student or any source. I have not given my code
 * to any student.
 * Pierre Aba
 */

// Abstract class representing a beverage
public abstract class Beverage {
    private String bevName; // Name of the beverage
    private Type type; // Type of the beverage (enum)
    private Size size; // Size of the beverage (enum)
    private static final double BASE_PRICE = 2.0; // Base price of the beverage
    private static final double SIZE_PRICE = 1.0; // Additional price for larger size

    // Constructor to initialize beverage properties
    public Beverage(String beverageName, Type beverageType, Size size) {
        this.bevName = beverageName;
        this.type = beverageType;
        this.size = size;
    }

    // Abstract method to calculate the price of the beverage (to be implemented by subclasses)
    public abstract double calcPrice();

    // Override toString method to provide a string representation of the beverage
    @Override
    public String toString() {
        return "Beverage: " + bevName + ", Size: " + size;
    }

    // Check if two beverages are equal based on their properties
    public boolean equals(Beverage bev) {
        return bevName.equals(bev.bevName) &&
               type == bev.type &&
               size == bev.size;
    }

    // Getters and setters for beverage properties
    public void setSize(Size size) {
        this.size = size;
    }
    public void setBeverageName(String beverageName) {
        this.bevName = beverageName;
    }
    public void setBeverageType(Type beverageType) {
        this.type = beverageType;
    }

    // Getters for beverage properties
    public Type getType() {
        return type;
    }
    public String getBevName() {
        return bevName;
    }
    public Size getSize() {
        return size;
    }
    
    // Get the base price of the beverage
    public double getBasePrice() {
        return BASE_PRICE;
    }
    
    // Calculate and return the total price of the beverage including size cost
    public double addSizePrice() {
        Size size = getSize();
        switch(size) {
            case SMALL: return getBasePrice();
            case MEDIUM: return getBasePrice() + SIZE_PRICE;
            case LARGE: return getBasePrice() + (2 * SIZE_PRICE);
        }
        return getBasePrice();
    }
}
