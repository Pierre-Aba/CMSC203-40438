import java.io.*;
import java.util.Scanner;

public class HolidayBonus {
    
    public HolidayBonus() {
        //  Default Constructor
    }
    
    public static double[] calculateHolidayBonus(double[][] data) {
        double[] bonuses = new double[data.length];
        
        for (int store = 0; store < data.length; store++) {
            int columns = data[store].length;
          
            
            double bonus = 0.0;
            
            for (int col = 0; col < columns; col++) {
                double currentSales = data[store][col];
                double highestSales = TwoDimRaggedArrayUtility.getHighestInColumn(data, col);
                double lowestSales = TwoDimRaggedArrayUtility.getLowestInColumn(data, col);
                if (currentSales <= 0) {
                    // No bonus for zero sales
                    bonus += 0;
                } else if (currentSales == highestSales) {
                    // Highest row gets $5000
                    bonus += 5000;
                } else if (currentSales == lowestSales&&currentSales!=0) {
                    // Lowest row gets $1000
                    bonus += 1000;
                } else {
                    // All other rows get $2000
                    bonus += 2000;
                }
            }
            
            bonuses[store] = bonus;
        }
        
        return bonuses;
    }
    
    public static double calculateTotalHolidayBonus(double[][] data) {
     double totalBonus = 0.0;
        double[] bonuses = HolidayBonus.calculateHolidayBonus(data); // calls the other static method
        for(double total : bonuses)
        	totalBonus+=total;
        return totalBonus;
    }
}
