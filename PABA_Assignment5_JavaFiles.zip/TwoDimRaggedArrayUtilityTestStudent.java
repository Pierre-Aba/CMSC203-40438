import static org.junit.Assert.*;
import org.junit.Test;
import java.io.*;
import java.util.Arrays;

public class TwoDimRaggedArrayUtilityTestStudent {

    @Test
    public void testGetAverage() {
        double[][] array = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
        double expectedAverage = 3.5;
        double actualAverage = TwoDimRaggedArrayUtility.getAverage(array);
        assertEquals(expectedAverage, actualAverage, 0.0001);
    }

    @Test
    public void testGetColumnTotal() {
        double[][] array = {{1.0, 2.0, 3.0}, {4.0, 5.0, 6.0}};
        int columnIndex = 1;
        double expectedTotal = 7.0;
        double actualTotal = TwoDimRaggedArrayUtility.getColumnTotal(array, columnIndex);
        assertEquals(expectedTotal, actualTotal, 0.0001);
    }

    // Similar tests for other methods...

    @Test
    public void testReadFile() throws FileNotFoundException {
        File file = new File("test_input.txt");
        double[][] expectedArray = {{1.0, 2.0}, {3.0}, {4.0, 5.0, 6.0}};
        double[][] actualArray = TwoDimRaggedArrayUtility.readFile(file);
        assertTrue(Arrays.deepEquals(expectedArray, actualArray));
    }

    @Test
    public void testWriteToFile() throws IOException {
        double[][] array = {{1.0, 2.0}, {3.0}, {4.0, 5.0, 6.0}};
        File outputFile = new File("test_output.txt");
        
        // Write the array to the file
        TwoDimRaggedArrayUtility.writeToFile(array, outputFile);
        
        // Read the written file and compare its contents to the original array
        double[][] readArray = TwoDimRaggedArrayUtility.readFile(outputFile);
        assertTrue(Arrays.deepEquals(array, readArray));
        
        // Clean up: delete the output file
        outputFile.delete();
    }
}
