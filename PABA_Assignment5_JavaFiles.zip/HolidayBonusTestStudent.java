import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class HolidayBonusTestStudent {
	private double[][] data = {
            {10000, 15000, 20000},
            {8000, 12000, 18000},
            {5000, 10000}
        };
    @Test
    void testCalculateHolidayBonus() {
        
    	try {
			double[] result = HolidayBonus.calculateHolidayBonus(data);
			assertEquals(15000.0, result[0], .001);
			assertEquals(6000.0, result[1], .001);
			assertEquals(2000.0, result[2], .001);
		} catch (Exception e) {
			fail("This should not have caused an Exception");
		}
    }
    

    @Test
    void testCalculateTotalHolidayBonus() {
       
        double expectedTotalBonus = 23000;
        double actualTotalBonus = HolidayBonus.calculateTotalHolidayBonus(data);
        assertEquals(expectedTotalBonus, actualTotalBonus, 0.001);
    }
}
