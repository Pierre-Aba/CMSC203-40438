import java.io.*;
import java.util.Scanner;

public class TwoDimRaggedArrayUtility {
	 
	public TwoDimRaggedArrayUtility()
		{
			
		}
    
	// Returns the average of the elements in the two-dimensional array
    public static double getAverage(double[][] retailStores) {
        int totalElements = 0;
        double sum = 0.0;
        
        for (double[] row : retailStores) {
            for (double value : row) {
                sum += value;
                totalElements++;
            }
        }
        double avg = sum/totalElements;
        return avg;
    }
    
    // Returns the total of the selected column in the two-dimensional array
    public static double getColumnTotal(double[][] retailStores, int col) {
        double total = 0.0;
        
        for (double[] row : retailStores) {
            if (col < row.length) {
                total += row[col];
            }
        }
        
        return total;
    }
    
    // Returns the largest element in the two-dimensional array
    public static double getHighestInArray(double[][] retailStores) {
        double highest = retailStores[0][0];
        
        for (double[] row : retailStores) {
            for (double value : row) {
                if (value > highest) {
                    highest = value;
                }
            }
        }
        
        return highest;
    }
    
    // Returns the largest element of the selected column in the two-dimensional array
    public static double getHighestInColumn(double[][] retailStores, int col) {
        double highest = retailStores[0][col];
        
        for (double[] row : retailStores) {
            if (col < row.length && row[col] > highest) {
                highest = row[col];
            }
        }
        
        return highest;
    }
    
    // Returns the index of the largest element of the selected column in the two-dimensional array
    public static int getHighestInColumnIndex(double[][] retailStores, int col) {
        double highest = retailStores[0][col];
        int highestIndex = 0;
        
        for (int i = 0; i < retailStores.length; i++) {
            if (col < retailStores[i].length && retailStores[i][col] > highest) {
                highest = retailStores[i][col];
                highestIndex = i;
            }
        }
        
        return highestIndex;
    }
    
    // Returns the largest element of the selected row in the two-dimensional array
    public static double getHighestInRow(double[][] retailStores, int row) {
        double highest = retailStores[row][0];
        
        for (double value : retailStores[row]) {
            if (value > highest) {
                highest = value;
            }
        }
        
        return highest;
    }
    
    // Returns the index of the largest element of the selected row in the two-dimensional array
    public static int getHighestInRowIndex(double[][] retailStores, int row) {
        double highest = retailStores[row][0];
        int highestIndex = 0;
        
        for (int i = 0; i < retailStores[row].length; i++) {
            if (retailStores[row][i] > highest) {
                highest = retailStores[row][i];
                highestIndex = i;
            }
        }
        
        return highestIndex;
    }
    
    // Returns the smallest element in the two-dimensional array
    public static double getLowestInArray(double[][] retailStores) {
        double lowest = retailStores[0][0];
        
        for (double[] row : retailStores) {
            for (double value : row) {
                if (value < lowest) {
                    lowest = value;
                }
            }
        }
        
        return lowest;
    }
    
    // Returns the smallest element of the selected column in the two-dimensional array
    public static double getLowestInColumn(double[][] retailStores, int col) {
        double lowest = retailStores[0][col];
        
        for (double[] row : retailStores) {
            if (col < row.length && row[col] < lowest) {
                lowest = row[col];
            }
        }
        
        return lowest;
    }
    
    // Returns the index of the smallest element of the selected column in the two-dimensional array
    public static int getLowestInColumnIndex(double[][] retailStores, int col) {
        double lowest = retailStores[0][col];
        int lowestIndex = 0;
        
        for (int i = 0; i < retailStores.length; i++) {
            if (col < retailStores[i].length && retailStores[i][col] < lowest) {
                lowest = retailStores[i][col];
                lowestIndex = i;
            }
        }
        
        return lowestIndex;
    }
    
    // Returns the smallest element of the selected row in the two-dimensional array
    public static double getLowestInRow(double[][] retailStores, int row) {
        double lowest = retailStores[row][0];
        
        for (double value : retailStores[row]) {
            if (value < lowest) {
                lowest = value;
            }
        }
        
        return lowest;
    }
    
    // Returns the index of the smallest element of the selected row in the two-dimensional array
    public static int getLowestInRowIndex(double[][] retailStores, int row) {
        double lowest = retailStores[row][0];
        int lowestIndex = 0;
        
        for (int i = 0; i < retailStores[row].length; i++) {
            if (retailStores[row][i] < lowest) {
                lowest = retailStores[row][i];
                lowestIndex = i;
            }
        }
        
        return lowestIndex;
    }
    
    // Returns the total of the selected row in the two-dimensional array
    public static double getRowTotal(double[][] retailStores, int row) {
        double total = 0.0;
        
        for (double value : retailStores[row]) {
            total += value;
        }
        
        return total;
    }
    
    // Returns the total of all the elements of the two-dimensional array
    public static double getTotal(double[][] retailStores) {
        double total = 0.0;
        
        for (double[] row : retailStores) {
            for (double value : row) {
                total += value;
            }
        }
        
        return total;
    }
    
    // Reads from a file and returns a ragged array of doubles
    public static double[][] readFile(File file) throws FileNotFoundException {
        double[][] raggedArray = new double[6][];
        int row = 0;
        
        Scanner scanner = new Scanner(file);
        
        while (scanner.hasNextLine() && row < 10) {
            String line = scanner.nextLine();
            String[] elements = line.split(" ");
            //String.split(String regex, int limit) returns a string array computed by splitting the string with the delimiting string expression " " in this case
            int columns = Math.min(elements.length, 10); //min static method to make the array ragged
            raggedArray[row] = new double[columns];
            
            for (int col = 0; col < columns; col++) {
                raggedArray[row][col] = Double.parseDouble(elements[col]);
            }
            
            row++;
        }
        
        scanner.close();
        return raggedArray;
    }
    
    // Writes the ragged array of doubles into the file
    public static void writeToFile(double[][] retailStores, File outputFile) throws IOException {
        PrintWriter writer = new PrintWriter(outputFile);
        
        for (double[] row : retailStores) {
            for (int col = 0; col < row.length; col++) {
                writer.print(row[col]);
                if (col < row.length - 1) {
                    writer.print(" ");
                }
            }
            writer.println();
        }
        
        writer.close();
    }
}
